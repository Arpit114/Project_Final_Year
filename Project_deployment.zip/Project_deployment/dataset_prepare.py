import cv2
import os

def face_detect(path, roll, branch,batch, root):
    print("detecting")
    detector = cv2.CascadeClassifier(cv2.data.haarcascades +"haarcascade_frontalface_default.xml")
    print(detector)
    images = os.listdir(path)
    print(images)
    temp = 0
    for i in images:
        try:
            image = cv2.imread(path+os.sep+i)
            print(path+os.sep+i)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            face = detector.detectMultiScale(gray, 1.3, 5, minSize=(30, 30), flags = cv2.CASCADE_SCALE_IMAGE)
            temp = temp+1
            for x,y,w,h in face:
                cv2.imwrite(root+os.sep+"dataset"+os.sep+batch+os.sep+branch+os.sep+roll+"_"+str(temp)+".jpg", gray[y:y+h, x:x+w])
                print("detected")
        except:
            continue
    return 1


