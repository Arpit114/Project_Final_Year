from flask import Flask, render_template, url_for, request, redirect,flash, jsonify, json,session
from flask_session import Session
from flask_login import logout_user
from flask_ngrok import run_with_ngrok
from dataset_prepare import face_detect
import modelTrain
import os
import MySQLdb
import shutil
import zipfile
import recognition
import secrets

app = Flask(__name__ )
#run_with_ngrok(app)
#----------------------------------------------------
secret = secrets.token_urlsafe(32)
app.secret_key = secret
#---------------------------------------------------
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
print(APP_ROOT)

conn = MySQLdb.connect(host="127.0.0.1",port=3306,user="root",password="arpit114",db="attendance_database")
conn.autocommit(on=True)


# ---------------------------------HOMEPAGE---------------------------------------------------------
  
@app.route("/", methods=["POST", "GET"])
def index():
  if request.method=="POST":
    loginAs = request.values.get("loginAs")
    username = request.values.get("username")
    session['user'] = username
    password = request.values.get("password")
    cursor = conn.cursor()
    if loginAs=="Admin":
      result = cursor.execute("SELECT * FROM admin_login WHERE binary username=%s AND binary password=%s;",(username,password))
      if result==1:
        return redirect(url_for("admin"))
      else:
        msg ="Invalid Username or Password"
        return render_template("index.html", error_msg=msg)
    elif loginAs=="Student":
      result = cursor.execute("SELECT * FROM student_login WHERE binary binary student_name=%s AND roll_no=%s ;",(username.capitalize(),password))
      if result==1:
        cursor.execute("SELECT branch FROM student_login WHERE student_name=%s AND roll_no=%s;",(username.capitalize(),password))
        br = cursor.fetchall()
        if '' in br[0]:
          return redirect(url_for("studentReg"))
        else:
          result = cursor.execute("SELECT COUNT(DISTINCT attendance_date) FROM attendance WHERE batch=(SELECT DISTINCT batch FROM attendance WHERE student_ID= %s) and branch=(SELECT DISTINCT branch FROM attendance where student_ID=%s);",(password,password))
          if result == 1:
            total = cursor.fetchall()
            total = total[0][0]
            cursor.execute("SELECT COUNT(DISTINCT attendance_date) FROM attendance WHERE student_ID=%s AND attendance_status='Present';",[password])
            present = cursor.fetchall()
            present = present[0][0]
            absent = total-present
          return redirect(url_for('studentDashboard', user_id=password,present=present, absent=absent))
      else:
        msg ="Invalid Username or Password"
        return render_template("index.html", error_msg=msg)
    elif loginAs=="Faculty":
      result = cursor.execute("SELECT * FROM faculty_login WHERE binary faculty_name=%s AND binary faculty_id=%s;",(username.capitalize(),password))
      if result==1:
        cursor.execute("SELECT department FROM faculty_login WHERE faculty_name=%s AND faculty_id=%s;",(username.capitalize(),password))
        dp =cursor.fetchall()
        if '' in dp[0]:
          return redirect(url_for("fReg"))
        else:
          return redirect(url_for("faculty", facul_id=password))
      else:
        msg ="Invalid Username or Password"
        return render_template("index.html", error_msg=msg)
  else:  
    return render_template("index.html")

@app.after_request
def set_response_headers(response):
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

#--------------------------------------ADMIN DASHBOARD-------------------------------------------------
@app.route("/admin/", methods=["POST","GET"])
def admin():
  if request.method=="POST":
    batch = str(request.values.get("batch"))
    branch = str(request.values.get("branch"))
    ret = modelTrain.TrainImages(APP_ROOT, batch, branch)
    if ret==1:
      msg = "Model Trained Successfully"
    else:
      msg = "Images not present for the specified branch"
    return render_template("dashB_admin.html",msg = msg)
  else:  
    return render_template("dashB_admin.html")


@app.route("/admin/delete", methods=["POST", "GET"])
def deleteStudent():
  if request.method=="POST":
    entity = str(request.values.get("remove_id"))
    roll_id = str(request.values.get("id"))
    if entity=="Student":
      cursor = conn.cursor()
      ret = cursor.execute("DELETE FROM student_login WHERE binary roll_no= %s",[roll_id])
      if ret==1:
        msg = "Successfully removed {}".format(roll_id)
        return render_template("admin_remove.html", msg = msg)
    elif entity=="Faculty":
      cursor = conn.cursor()
      ret = cursor.execute("DELETE FROM faculty_login WHERE binary faculty_id= %s",[roll_id])
      if ret==1:
        msg = "Successfully removed {}".format(roll_id)
        return render_template("admin_remove.html", msg = msg)
  else:
    return render_template("admin_remove.html")


@app.route("/admin/addRecord", methods=["POST","GET"])
def addRecord():
  if request.method=="POST":
    entity= str(request.values.get("add_id"))
    username = str(request.values.get("username"))
    password = str(request.values.get("password"))
    cursor = conn.cursor()
    if entity == 'Student':
      try:
        ret = cursor.execute("INSERT INTO student_login VALUES (%s, %s,'','');",(username.capitalize(), password))
        if ret==1:
          msg = "Added Student Login Successfully"
          return render_template("admin_add.html", msg = msg )
      except:
        msg = "This record is already in the database"
        return render_template("admin_add.html", msg = msg )
    elif entity=="Faculty":
      ret = cursor.execute("INSERT INTO faculty_login VALUES (%s, %s,'');",(username.capitalize(), password))
      if ret==1:
        msg = "Added Faculty Login Successfully"
        return render_template("admin_add.html", msg = msg )
      else:
        msg = "This record is already in the database"
        return render_template("admin_add.html", msg = msg )
  else:
      return render_template("admin_add.html")

# -----------------------------------STUDENT REGISTRATION----------------------------------------------


def unzip_file(zip_src, dst_dir):
    r = zipfile.is_zipfile(zip_src)
    print("Enter function")
    if r:
      fz = zipfile.ZipFile(zip_src, "r")
      fzx = fz.filename
      fzx = fzx.split("\\")
      fzx = fzx[-1]
      fzx = fzx.split(".")
      fzx = fzx[0]
      for file in fz.namelist():
        fz.extract(file, dst_dir)
      print("extracted")
      return fzx
    else:
      print("Not extracted")
      return 0


@app.route("/studentReg", methods=["GET","POST"])
def studentReg():
  if request.method=="POST":
    roll_id = str(request.values.get("roll_id"))
    branch = str(request.values.get("Branch"))
    batch = str(request.values.get("batch"))
    zipfile = request.files.get("file")
    cursor = conn.cursor()
    result = cursor.execute("SELECT batch from student_login where binary roll_no=%s;",[roll_id])
    if result==0:
      msg="Enter roll_id correctly"
      return render_template("registration.html", msg = msg)
    elif result==1:
      ba = cursor.fetchall()
      if '' not in ba[0]:
        msg = "This roll_id is already registered"
        return render_template("registration.html", msg = msg)
      else:
        target = os.path.join(APP_ROOT,"Uploads",str(batch),str(branch))
        try:
          zip_src = os.path.join(APP_ROOT, "zip_uploads",zipfile.filename)
          zipfile.save(zip_src)
          print("done")
          ret = unzip_file(zip_src, target)
          print("ret = ",ret)
          if ret==0:
            return render_template("registration.html", msg = "Please upload zip file")
          else:
            os.remove(zip_src)
            os.rename(os.path.join(target,ret),os.path.join(target,roll_id) )
            #shutil._unpack_archive(zipfile, target, format="zip")
            print("done")
            cursor.execute("UPDATE student_login SET branch=%s , batch = %s WHERE roll_no=%s;",(branch, batch,roll_id))
            x = face_detect(os.path.join(target,roll_id), roll_id, branch, batch, APP_ROOT)
            print(x)
            shutil.rmtree(os.path.join(target,roll_id), ignore_errors=True)
            msg = "Details Uploaded Successfully...You can login Now"
            return render_template("registration.html", msg = msg)
        except:
          msg = "Something went wrong...Try Again !!"
          return render_template("registration.html", msg = msg)
  else:
    msg = "You are not registered for attendance. Enter your details please !!"
    return render_template("registration.html", msg = msg)


@app.route("/studentDashboard",methods=["GET","POST"])
def studentDashboard():
  if request.method=="POST":
    s_ID = request.values.get("roll")
    from_date = str(request.values.get("from"))
    to_date = str(request.values.get("to"))
    print(to_date)
    cursor = conn.cursor()
    ret = cursor.execute("SELECT a.student_ID,f.faculty_name ,a.batch, a.branch, a.attendance_date, a.attendance_status FROM faculty_login f, attendance a WHERE student_ID=%s and attendance_date between %s and %s AND f.faculty_id=a.faculty_ID;",(s_ID, from_date, to_date))
    result = cursor.fetchall()
    return render_template("view_attendance.html", result=result)
  return render_template("dashB_stud.html", user_id=request.args.get("user_id"), present=request.args.get("present"),absent=request.args.get("absent"))


# ------------------------------------------FACULTY REGISTRATION------------------------------------------------

@app.route("/fReg", methods=["GET","POST"])
def fReg():
  if request.method=="POST":
    fID = request.values.get("fID")
    deptt = request.values.get("Deptt")
    cursor = conn.cursor()
    result = cursor.execute("SELECT department FROM faculty_login WHERE binary faculty_id=%s",[fID])
    if result == 0:
      msg = "Enter roll_id correctly"
      return render_template("faculty_reg.html", msg=msg)
    elif result == 1:
      dep = cursor.fetchall()
      if '' not in dep[0]:
        msg = "This faculty id is already registered"
      else:
        cursor.execute("UPDATE faculty_login SET department=%s WHERE faculty_id=%s",(deptt, fID))
        msg = "Registered Successfully...you can login now..!!"
        return render_template("faculty_reg.html", msg=msg)
  else:
    msg = "You are not registered. Enter your details please !!"
    return render_template("faculty_reg.html", msg=msg)

# -------------------------------------FACULTY DASHBOARD-----------------------------------------------

@app.route("/faculty", methods=["GET","POST"])
def faculty():
  if request.method=="POST":
    fac_id = request.values.get("faculty_id")
    batch = request.values.get("batch")
    branch = request.values.get("branch")
    date = request.values.get("date")
    upload = request.files.get("file")
    print(upload)
    cursor =conn.cursor()
    result = cursor.execute("SELECT * FROM attendance WHERE attendance_date=%s AND batch=%s AND branch= %s",(date,batch,branch))
    ret = cursor.fetchall()
    print(ret)
    if len(ret)!=0:
      msg = "You have already uploaded the attendance for this class for specified date"
      return render_template("dashB_faculty.html", msg=msg, facul_id=request.args.get("facul_id"))
    else:
      target = os.path.join(APP_ROOT, "attendance",upload.filename)
      upload.save(target)
      os.rename(target, os.path.join(APP_ROOT,"attendance",batch+"_"+branch+"_"+date+".mp4"))
      file_path = os.path.join(APP_ROOT,"attendance",batch+"_"+branch+"_"+date+".mp4")
      recognized =recognition.recognize_attendence(APP_ROOT,file_path, branch, batch)
      cursor.execute("SELECT roll_no from student_login where batch=%s and branch=%s",(batch,branch))
      arr = list(cursor.fetchall())
      for i in arr:
        if i[0] in recognized:
          cursor.execute("INSERT INTO attendance VALUES(%s,%s,%s,%s,%s,'Present')",(i[0],fac_id,batch,branch,date))
        else:
          cursor.execute("INSERT INTO attendance VALUES(%s,%s,%s,%s,%s,'Absent')",(i[0],fac_id,batch,branch,date))
      msg = "Attendance saved Successfully"
      return render_template("dashB_faculty.html", msg=msg,facul_id=request.args.get("facul_id"))
  else:
    return render_template("dashB_faculty.html",facul_id=request.args.get("facul_id"))

@app.route("/faculty/edit_attendance", methods=["GET","POST"])
def edit():
  if request.method=="POST":
    faculty = request.values.get("fID")
    s_id = request.values.get("s_id")
    status = request.values.get("status")
    date = request.values.get("date")
    cursor = conn.cursor()
    ret = cursor.execute("UPDATE attendance SET faculty_ID=%s, attendance_status=%s WHERE student_ID=%s AND attendance_date=%s;",(faculty,status, s_id, date))
    if ret==1:
      msg = "Attendance Updated Successfully"
    else:
      msg = "No previous record for the given details found !!"
    return render_template("edit_att.html", msg=msg)
  else:
    return render_template("edit_att.html")

@app.route("/faculty/view_attendance", methods=["GET","POST"])
def faculty_view():
  if request.method=="POST":
    batch =  str(request.values.get("batch"))
    branch = str(request.values.get("branch"))
    from_date = str(request.values.get("from"))
    to_date = str(request.values.get("to"))
    print(to_date)
    cursor = conn.cursor()
    ret = cursor.execute("SELECT student_ID, batch, branch, attendance_date,attendance_status FROM attendance WHERE batch=%s AND branch=%s AND attendance_date between %s and %s;",(batch,branch, from_date, to_date))
    result = cursor.fetchall()
    return render_template("faculty_view.html", result=result)
  else:
    return render_template("faculty_view.html")
    


# ----------------------------------------ABOUT-------------------------------------------------------

@app.route("/about")
def about():
  return render_template("About.html")



if __name__ == "__main__":
  app.run(debug=True)