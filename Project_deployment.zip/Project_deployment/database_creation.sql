CREATE DATABASE `attendance_database` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;

use `attendance_database`;

CREATE TABLE `admin_login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(15) NOT NULL,
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `faculty_login` (
  `faculty_name` varchar(50) NOT NULL,
  `faculty_id` varchar(25) NOT NULL,
  `department` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`faculty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `student_login` (
  `student_name` varchar(30) NOT NULL,
  `roll_no` varchar(15) NOT NULL,
  `branch` varchar(20) DEFAULT NULL,
  `batch` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`roll_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `attendance` (
  `student_ID` varchar(30) NOT NULL,
  `faculty_ID` varchar(25) NOT NULL,
  `batch` varchar(20) NOT NULL,
  `branch` varchar(20) NOT NULL,
  `attendance_date` date NOT NULL,
  `attendance_status` varchar(10) DEFAULT 'Absent',
  PRIMARY KEY (`attendance_date`,`branch`,`batch`,`student_ID`),
  KEY `student_ID` (`student_ID`),
  KEY `faculty_ID` (`faculty_ID`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_ID`) REFERENCES `student_login` (`roll_no`),
  CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`faculty_ID`) REFERENCES `faculty_login` (`faculty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `attendance_database`.`admin_login`
(`username`,
`password`)
VALUES
('admin','arpit114');
