import cv2
import numpy as np
import os
from PIL import Image
from threading import Thread


def getImagesAndLabels(path):
    imagePaths = [os.path.join(path,f) for f in os.listdir(path)]
    faces = []
    Ids = []
    for imagePath in imagePaths:
        pilImage = Image.open(imagePath).convert("L")
        imageNp = np.array(pilImage, 'uint8')
        print(imageNp)
        Id = int(imagePath.split(os.sep)[-1].split("_")[0])
        faces.append(imageNp)
        Ids.append(Id)
    return faces, Ids

def TrainImages(root,batch,branch):
    path = os.path.join(root,"dataset", batch, branch)
    print(path)
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    detector = cv2.CascadeClassifier(cv2.data.haarcascades +"haarcascade_frontalface_default.xml")
    faces, Id = getImagesAndLabels(path)
    Thread(target = recognizer.train(faces, np.array(Id))).start()
    target_path = os.path.join(root,"models",batch,branch)
    recognizer.save(os.path.join(target_path,"trainer.yml"))
    return 1
