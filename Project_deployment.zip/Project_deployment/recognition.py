import os
import cv2
import numpy as np


def recognize_attendence(root, path, branch, batch):
    model_path = os.path.join(root,"models",batch,branch,"trainer.yml")
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(model_path)
    faceCascade = cv2.CascadeClassifier(cv2.data.haarcascades +"haarcascade_frontalface_default.xml")
    cap = cv2.VideoCapture(path)  
    minW = 0.1 * cap.get(3)
    minH = 0.1 * cap.get(4)
    face = []
    while True:
        try:
            _, img = cap.read()  
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = faceCascade.detectMultiScale(gray, 1.2, 5,minSize = (int(minW), int(minH)), flags= cv2.CASCADE_SCALE_IMAGE)
            for(x, y, w, h) in faces:
                Id, conf = recognizer.predict(gray[y:y+h, x:x+w])
                if conf<100:
                    face.append(str(Id))
        except:
            break
    cap.release()
    face = list(set(face))
    return face